import UIKit

class InfoCellCollectionViewCell: UICollectionViewCell {
  @IBOutlet weak var imageView: UIImageView!
  @IBOutlet weak var labelView: UILabel!
    
}
