import UIKit
import MapKit

class LocationsViewController: UIViewController {
  
  @IBOutlet weak var legendView: UITextView!
  @IBOutlet weak var mapView: MKMapView!
  
  
  override func viewDidLoad() {
    super.viewDidLoad()
    self.mapView.delegate = self
    // Do any additional setup after loading the view.
    self.addAnotations()
    self.updateLegend()
  }
  
  
  func addAnotations() {
    // School
    let feitAnnotation = MKPointAnnotation()
    feitAnnotation.title = "FEIT"
    let coordinatesFeit = [42.004830, 21.408330]
    feitAnnotation.coordinate = CLLocationCoordinate2D(latitude: coordinatesFeit[0],
                                                       longitude: coordinatesFeit[1])
    
    // Anex
    let anexAnnotation = MKPointAnnotation()
    anexAnnotation.title = "ANEX"
    let coordinatesAnex = [42.004421, 21.408088]
    anexAnnotation.coordinate = CLLocationCoordinate2D(latitude: coordinatesAnex[0],
                                                       longitude: coordinatesAnex[1])
    
    // TMF
    let tmfAnnotation = MKPointAnnotation()
    tmfAnnotation.title = "TMF"
    let coordinatesTmf = [42.004853, 21.410171]
    tmfAnnotation.coordinate = CLLocationCoordinate2D(latitude: coordinatesTmf[0],
                                                       longitude: coordinatesTmf[1])
    
    // Add Anotations
    let anotations = [feitAnnotation, anexAnnotation, tmfAnnotation]
    mapView.showAnnotations(anotations, animated: true)
    
  }
  
  func updateLegend() {
    let text = """
1. Машински Факултет
2. АНЕКС Зграда
3. Технолошки факултет
"""
    self.legendView.text = text
  }
  
  
  /*
   // MARK: - Navigation
   
   // In a storyboard-based application, you will often want to do a little preparation before navigation
   override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
   // Get the new view controller using segue.destination.
   // Pass the selected object to the new view controller.
   }
   */
  
}

extension LocationsViewController: MKMapViewDelegate {
  func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
      if annotation is MKUserLocation {
          return nil
      }
      
      var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: "custom")
      
      if annotationView == nil {
          //Create View
          annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "custom")
      } else {
          //Assign annotation
          annotationView?.annotation = annotation
      }
      
      //Set image
      switch annotation.title {
      case "FEIT":
          annotationView?.image = UIImage(systemName: "1.circle.fill")
      case "ANEX":
          annotationView?.image = UIImage(systemName: "2.circle.fill")
      case "TMF":
        annotationView?.image = UIImage(systemName: "3.circle.fill")
      default:
          break
      }
      
      return annotationView
  }
}
