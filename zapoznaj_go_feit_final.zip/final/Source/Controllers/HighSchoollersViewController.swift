import UIKit
import SafariServices

class HighSchoollersViewController: UIViewController {

  @IBOutlet weak var collectionsView: UICollectionView!
  
  let infoCell = "infoCell"
  override func viewDidLoad() {
        super.viewDidLoad()
    self.collectionsView.delegate = self
    self.collectionsView.dataSource = self
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension HighSchoollersViewController: UICollectionViewDelegate {
  
  func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    self.showTutorial(indexPath.row)
  }

}

extension HighSchoollersViewController: UICollectionViewDataSource {
  
  func numberOfSections(in collectionView: UICollectionView) -> Int {
    return 1
  }
  
  func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    return 5
  }
  
  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    
    let reusableCell = collectionView.dequeueReusableCell(
      withReuseIdentifier: infoCell,
      for: indexPath) as! InfoCellCollectionViewCell
    
    switch indexPath.row {
    case 1:
      reusableCell.labelView.text = "Конкурс и Квоти"
      reusableCell.imageView.image = UIImage(systemName: "chart.bar.xaxis")
    case 2:
      reusableCell.labelView.text = "Пријавување"
      reusableCell.imageView.image = UIImage(systemName: "signature")
    case 3:
      reusableCell.labelView.text = "Рокови"
      reusableCell.imageView.image = UIImage(systemName: "clock")
    case 4:
      reusableCell.labelView.text = "Стипендии"
      reusableCell.imageView.image = UIImage(systemName: "bag.badge.plus")
    default:
      reusableCell.labelView.text = "Резултати"
      reusableCell.imageView.image = UIImage(systemName: "paperclip.badge.ellipsis")
    }
    
    reusableCell.shadowDecorate()
    
    return reusableCell
    
  }
  
  func showTutorial(_ which: Int) {
    switch which {
    case 1:
      openBrowser("https://feit.ukim.edu.mk/upisi/konkurs-i-kvoti/")
    case 2:
      openBrowser("https://feit.ukim.edu.mk/upisi/prijavuvanje/")
    case 3:
      openBrowser("https://feit.ukim.edu.mk/upisi/rokovi/")
    case 4:
      openBrowser("https://feit.ukim.edu.mk/upisi/stipendii/")
    default:
      openBrowser("https://feit.ukim.edu.mk/upisi/rezultati/")
    }
  }
  
  func openBrowser(_ urlString: String) {
    if let url = URL(string: urlString) {
        let config = SFSafariViewController.Configuration()
        config.entersReaderIfAvailable = true

        let vc = SFSafariViewController(url: url, configuration: config)
        present(vc, animated: true)
    }
  }
  
}

