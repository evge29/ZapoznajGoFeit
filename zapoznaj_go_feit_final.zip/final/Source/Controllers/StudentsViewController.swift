import UIKit
import SafariServices

class StudentsViewController: UIViewController {

  @IBOutlet weak var collectionsView: UICollectionView!
  
  let reuseIdentifier = "collectionItemCell"
  
  override func viewDidLoad() {
    super.viewDidLoad()
    self.collectionsView.delegate = self
    self.collectionsView.dataSource = self
    // Do any additional setup after loading the view.
  }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension StudentsViewController: UICollectionViewDelegate {
  
  func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    self.showTutorial(indexPath.row)
  }

}

extension StudentsViewController: UICollectionViewDataSource {
  
  func numberOfSections(in collectionView: UICollectionView) -> Int {
    return 1
  }
  
  func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    return 5
  }
  
  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    
    let reusableCell = collectionView.dequeueReusableCell(
      withReuseIdentifier: reuseIdentifier,
      for: indexPath) as! InfoCellCollectionViewCell
    
    switch indexPath.row {
    case 1:
      reusableCell.labelView.text = "Распоред"
      reusableCell.imageView.image = UIImage(systemName: "calendar")
    case 2:
      reusableCell.labelView.text = "Консултации"
      reusableCell.imageView.image = UIImage(systemName: "newspaper")
    case 3:
      reusableCell.labelView.text = "Контакт"
      reusableCell.imageView.image = UIImage(systemName: "envelope")
    case 4:
      reusableCell.labelView.text = "Студентски прашања"
      reusableCell.imageView.image = UIImage(systemName: "person.fill.questionmark")
    default:
      reusableCell.labelView.text = "Помош"
      reusableCell.imageView.image = UIImage(systemName: "exclamationmark.triangle")
    }
    
    reusableCell.shadowDecorate()
    
    return reusableCell
    
  }
  
  func showTutorial(_ which: Int) {
    switch which {
    case 1:
      openBrowser("https://feit.ukim.edu.mk/i-ciklus/raspored-na-chasovi/")
    case 2:
      openBrowser("https://feit.ukim.edu.mk/termini-za-konsultacii/")
    case 3:
      openBrowser("https://feit.ukim.edu.mk/en/staff/")
    case 4:
      openBrowser("https://feit.ukim.edu.mk/organizaciska-struktura/sluzhba-za-studentski-prashanja/")
    default:
      UIApplication.shared.open(URL(string: "tel://023099191")!, options: [:], completionHandler: nil)
    }
  }
  
  func openBrowser(_ urlString: String) {
    if let url = URL(string: urlString) {
        let config = SFSafariViewController.Configuration()
        config.entersReaderIfAvailable = true

        let vc = SFSafariViewController(url: url, configuration: config)
        present(vc, animated: true)
    }
  }
  
  
}

extension UICollectionViewCell {
    func shadowDecorate() {
        let radius: CGFloat = 10
        contentView.layer.cornerRadius = radius
        contentView.layer.borderWidth = 1
        contentView.layer.borderColor = UIColor.clear.cgColor
        contentView.layer.masksToBounds = true
    
        layer.shadowColor = UIColor.systemOrange.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 1.0)
        layer.shadowRadius = 2.0
        layer.shadowOpacity = 0.5
        layer.masksToBounds = false
        layer.shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: radius).cgPath
        layer.cornerRadius = radius
    }
}
