import UIKit
import Firebase

class SettingsViewController: UIViewController {

  @IBOutlet weak var signOutButton: UIButton!
  @IBOutlet weak var currentUser: UILabel!
  
  override func viewDidLoad() {
        super.viewDidLoad()

    guard let user = Auth.auth().currentUser else { return }
    self.currentUser.text = user.email
    }

  @IBAction func signOutTapped(_ sender: Any) {
    guard let user = Auth.auth().currentUser else { return }

    let onlineRef = Database.database().reference(withPath: "online/\(user.uid)")
    onlineRef.removeValue { error, _ in
      if let error = error {
        print("Removing online failed: \(error)")
        return
      }
      do {
        try Auth.auth().signOut()
        self.navigationController?.popToRootViewController(animated: true)
      } catch let error {
        print("Auth sign out failed: \(error)")
      }
    }
  }
}
